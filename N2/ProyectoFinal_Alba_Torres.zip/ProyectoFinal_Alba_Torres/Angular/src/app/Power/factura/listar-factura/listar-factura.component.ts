import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-factura',
  templateUrl: './listar-factura.component.html',
  styleUrls: ['./listar-factura.component.scss']
})
export class ListarFacturaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
