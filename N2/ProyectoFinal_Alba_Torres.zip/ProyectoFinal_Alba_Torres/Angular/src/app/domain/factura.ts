export class Factura{    
    fac_Codigo?:Number;
    per_id?: Number;
    fac_fecha?: Date;
    activo?: String;  
}