export class Detalles{    
    det_codigo?:Number;
    fac_codigo?: Number;
    pro_codigo?: Number;
    det_cantidad?: Number;
    det_precio?: Number;  
}