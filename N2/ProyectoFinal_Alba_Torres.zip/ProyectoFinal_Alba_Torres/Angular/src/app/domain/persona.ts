export class Persona{
    per_id?:Number;
    per_cedula?:String;
    per_Nombre?: String;
    per_Direccion?: String;

}