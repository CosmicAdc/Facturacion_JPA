export class Producto{
    pro_codigo?: number
    pro_precio?: number;
    pro_stock?: number;
    pro_nombre?: String;
}