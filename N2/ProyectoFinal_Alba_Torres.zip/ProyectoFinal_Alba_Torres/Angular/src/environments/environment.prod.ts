export const environment = {
  firebase: {
    projectId: 'comprasweb-alba',
    appId: '1:219246392536:web:ef081333a09176494693ad',
    storageBucket: 'comprasweb-alba.appspot.com',
    apiKey: 'AIzaSyCoLtYNdLLqPJV0Ic2Sp7c3jWvRdn6SZs8',
    authDomain: 'comprasweb-alba.firebaseapp.com',
    messagingSenderId: '219246392536',
  },
  production: true
};
